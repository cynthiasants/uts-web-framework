<section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2> Fasilitas </h2>
          <ol>
            <li><a href="<?php echo base_url('/') ?>">Home</a></li>
            <li>Fasilitas</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <section id="story-intro" class="story-intro">
      <div class="container">

        <div class="row">
          <div class="col-lg-12 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <!-- <h3>Fasilitas</h3> -->
            <p class="text-justify">
            Progam Studi S-1 Pendidikan Teknik Informatika dan Komputer FKIP UNS menempati gedung yang cukup luas, representative dan strategis di lingkungan FKI Universitas Sebelas Maret. Lokasi kampus berada di kampusKentingan Surakarta yang merupakan kampus pusat FKIP UNS. Fasilitas fisik tersebut akan dimanfaatkan secara optimal. Di lokasi tersebut juga telah tersedia laboratorium komputer yang cukup memadai dan representativeuntuk digunakan sebagai sarana pembelajaran pada Program Studi Pendidikan Teknik Informatika dan Komputer.
            </p>
            <p>
            <a href="">1. Gedung kuliah</a> 
            </p>
            <p>
            <a href="">2. Laboratorium</a> 
            </p>
            <p>
            <a href="">3. Perpustakaan</a> 
            </p>
            <p>
            <a href="">4. Studio Multimedia</a>
            </p>
          </div>
        </div>

      </div>
    </section>