<section id="breadcrumbs" class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2> Jalur Penerimaan </h2>
          <ol>
            <li><a href="<?php echo base_url('/') ?>">Home</a></li>
            <li>Akademik</li>
            <li>Jalur Penerimaan</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <section id="story-intro" class="story-intro">
      <div class="container">

        <div class="row">
          <div class="col-lg-12 pt-4 pt-lg-0 order-2 order-lg-1 content">
            <!-- <h3>Fasilitas</h3> -->
            <p class="text-justify">
                Sistem penerimaan mahasiswa baru di program studi pendidikan teknik informatika dan komputer Fakultas Keguruan dan Ilmu Pendidikan Universitas Sebelas Maret untuk tahun pertama yaitutahun 2012 hanya membuka 1 jalur yaitu sistem SPMB  . Sistem dan strategi rekruitmen mahasiswa baru jenjang S1 di program studi pendidikan teknik informatika dan komputer FKIP disesuaikan dengan sistem dan strategi rekruitmen mahasiswa baru untuk prodi baru di Universitas. Mahasiswa baru program studi S1 merupakan lulusan SMU/ SMK/ MA/ yang sederajat.
            </p>
            <p class="text-justify">
            Penerapan strategi di atas diharapkan berhasil mendapatkan input mahasiswa yang baik dan berkualitas di program studi pendidikan teknik informatika Fakultas Keguruan dan ilmu Pendidikan UNS.
            </p>
            <p>
            Alur pendaftaran dapat dilihat <a href=""> di sini. </a>
            </p>
          </div>
        </div>

      </div>
    </section>